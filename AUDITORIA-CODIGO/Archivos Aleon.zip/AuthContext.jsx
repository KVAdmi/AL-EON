import React, { createContext, useContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';

const AuthContext = createContext(null);

// 🔥 HELPER: Timeout para evitar loaders infinitos
function withTimeout(promise, ms = 8000) {
  return Promise.race([
    promise,
    new Promise((_, reject) => 
      setTimeout(() => reject(new Error('BOOT_TIMEOUT')), ms)
    )
  ]);
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [accessToken, setAccessToken] = useState(null);
  const [loading, setLoading] = useState(true);
  const [bootError, setBootError] = useState(null); // 🔥 NUEVO: Estado de error

  const loadUserProfile = async (userId) => {
    try {
      console.log('[BOOT] fetching profile for user:', userId);
      
      // 🔥 CON TIMEOUT: Si el fetch tarda más de 5s, abortar
      const profilePromise = supabase
        .from('user_profiles')
        .select('*')
        .eq('user_id', userId)
        .single();
      
      const { data, error } = await withTimeout(profilePromise, 5000);
      
      if (error) {
        console.error('[BOOT] ❌ Error cargando perfil:', error);
        return null;
      }
      
      console.log('[BOOT] ✅ profile loaded:', data?.display_name || data?.email);
      setUserProfile(data);
      return data;
    } catch (err) {
      console.error('[BOOT] ❌ Exception en loadUserProfile:', err);
      return null;
    }
  };

  // 🔥 NUEVO: Función para reintentar boot
  const retryBoot = () => {
    console.log('[BOOT] � Retry requested');
    setBootError(null);
    setLoading(true);
    initAuth();
  };

  // 🔥 FUNCIÓN PRINCIPAL DE INICIALIZACIÓN
  const initAuth = async () => {
    try {
      console.log('[BOOT] start');
      console.log('[BOOT] route=', window.location.pathname);
      
      // 🔥 CON TIMEOUT: Si tarda más de 8s, lanzar error
      await withTimeout(
        (async () => {
          const { data: { session } } = await supabase.auth.getSession();
          
          console.log('[BOOT] session=', !!session, 'user=', session?.user?.id);
          
          setUser(session?.user ?? null);
          setAccessToken(session?.access_token ?? null);
          
          if (session?.user) {
            await loadUserProfile(session.user.id);
          }
          
          console.log('[BOOT] ✅ done -> ready');
        })(),
        8000
      );
      
      setBootError(null);
    } catch (err) {
      console.error('[BOOT] ❌ error:', err.message || err);
      setBootError(err.message || 'ERROR_DESCONOCIDO');
    } finally {
      // 🔥 GARANTIZADO: Siempre apagar loading
      console.log('[BOOT] finally -> loading=false');
      setLoading(false);
    }
  };

  useEffect(() => {
    // 🔥 Listener para back/popstate
    const handlePopState = () => {
      console.log('[BOOT] 🔙 Popstate detected - aborting & resetting');
      setLoading(false);
      setBootError(null);
    };
    
    window.addEventListener('popstate', handlePopState);
    
    // 🔥 INICIAR AUTH CON TIMEOUT
    initAuth();

    // Escuchar cambios de autenticación
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      console.log('[AUTH] state change:', _event);
      setUser(session?.user ?? null);
      setAccessToken(session?.access_token ?? null);
      
      if (session?.user) {
        await loadUserProfile(session.user.id);
      } else {
        setUserProfile(null);
      }
    });

    return () => {
      window.removeEventListener('popstate', handlePopState);
      subscription.unsubscribe();
    };
  }, []);

  const login = async (email, password) => {
    try {
      console.log('[AUTH] login attempt for:', email);
      
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;
      
      console.log('[AUTH] ✅ login success');
      setUser(data.user);
      setAccessToken(data.session.access_token);
      
      return data;
    } catch (err) {
      console.error('[AUTH] ❌ login error:', err);
      throw err;
    }
  };

  const signup = async (email, password) => {
    try {
      console.log('[AUTH] signup attempt for:', email);
      
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
      });

      if (error) throw error;
      
      // Verificar que se creó el perfil (wait 2 segundos para que el trigger ejecute)
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const { data: profile, error: profileError } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('user_id', data.user?.id)
        .single();
      
      if (profileError || !profile) {
        console.error('[AUTH] ❌ Error: Perfil no creado automáticamente', profileError);
        throw new Error('Error creando perfil de usuario. Por favor contacta a soporte.');
      }
      
      console.log('[AUTH] ✅ Usuario registrado correctamente con perfil');
      return data;
    } catch (err) {
      console.error('[AUTH] ❌ signup error:', err);
      throw err;
    } finally {
      setLoading(false); // 🔥 GARANTIZADO: Apagar loading después de signup
    }
  };
  
  const logout = async () => {
    try {
      console.log('[AUTH] logout attempt');
      
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      
      console.log('[AUTH] ✅ logout success');
      
      // Limpiar estado
      setUser(null);
      setUserProfile(null);
      setAccessToken(null);
      setBootError(null);
      
      // Limpiar localStorage
      localStorage.clear();
      
      // ✅ Usar replace para evitar loops en history
      window.location.replace('/login');
    } catch (error) {
      console.error('[AUTH] ❌ logout error:', error);
      
      // Forzar limpieza y redirección incluso si hay error
      setUser(null);
      setUserProfile(null);
      setAccessToken(null);
      setBootError(null);
      localStorage.clear();
      window.location.replace('/login');
    } finally {
      // 🔥 GARANTIZADO: Apagar loading
      setLoading(false);
    }
  };

  const resetPassword = async (email) => {
    try {
      console.log('[AUTH] reset password for:', email);
      
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });

      if (error) throw error;
      
      console.log('[AUTH] ✅ reset email sent');
    } catch (err) {
      console.error('[AUTH] ❌ reset password error:', err);
      throw err;
    }
  };

  const updateDisplayName = async (newDisplayName) => {
    if (!user) return;
    
    try {
      console.log('[AUTH] updating display name to:', newDisplayName);
      
      const { error } = await supabase
        .from('user_profiles')
        .update({ display_name: newDisplayName })
        .eq('user_id', user.id);
      
      if (error) throw error;
      
      console.log('[AUTH] ✅ display name updated');
      
      // Actualizar el estado local
      setUserProfile(prev => ({ ...prev, display_name: newDisplayName }));
    } catch (err) {
      console.error('[AUTH] ❌ update display name error:', err);
      throw err;
    }
  };

  const value = {
    user,
    userProfile,
    accessToken,
    loading,
    bootError,      // 🔥 NUEVO: Exponer error
    retryBoot,      // 🔥 NUEVO: Exponer función de reintento
    login,
    signup,
    logout,
    resetPassword,
    updateDisplayName,
    refreshProfile: () => user && loadUserProfile(user.id)
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth debe usarse dentro de AuthProvider');
  }
  return context;
}
